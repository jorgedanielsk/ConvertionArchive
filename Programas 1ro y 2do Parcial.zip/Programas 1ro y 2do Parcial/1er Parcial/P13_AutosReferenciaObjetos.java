import java.util.Scanner;

class AutoP13 {
    private float precio;
    private int anio;
    private String marca;
    private String nombre;
    private String ap;
    private String am;
    private String genero;
    private int edad;

    public void setDatos(float precio, int anio, String marca, String nombre, String ap, String am, String genero, int edad) {
        this.precio = precio;
        this.anio = anio;
        this.marca = marca;
        this.nombre = nombre;
        this.ap = ap;
        this.am = am;
        this.genero = genero;
        this.edad = edad;
    }

    public void mostrarDatos() {
        System.out.println("\nDATOS DEL PROPIETARIO");
        System.out.println("Nombre: " + nombre + " " + ap + " " + am);
        System.out.println("Genero: " + genero);
        System.out.println("Edad: " + edad);
        System.out.println("\nDATOS DEL AUTO");
        System.out.println("Marca: " + marca);
        System.out.println("Precio: " + precio);
        System.out.println("Anio: " + anio);
    }
}

public class P13_AutosReferenciaObjetos {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        AutoP13[] lista = new AutoP13[3];

        for (int i = 0; i < 3; i++) {
            lista[i] = new AutoP13();
            System.out.println("\nPersona " + (i + 1));

            System.out.print("Nombre: ");
            String nombre = sc.next();
            System.out.print("Apellido paterno: ");
            String ap = sc.next();
            System.out.print("Apellido materno: ");
            String am = sc.next();
            System.out.print("Genero: ");
            String genero = sc.next();
            System.out.print("Edad: ");
            int edad = sc.nextInt();
            System.out.print("Marca del auto: ");
            String marca = sc.next();
            System.out.print("Precio: ");
            float precio = sc.nextFloat();
            System.out.print("Anio: ");
            int anio = sc.nextInt();

            lista[i].setDatos(precio, anio, marca, nombre, ap, am, genero, edad);
        }

        System.out.println("\n----- LISTA DE PERSONAS Y AUTOS -----");
        for (AutoP13 auto : lista) {
            auto.mostrarDatos();
        }
    }
}
