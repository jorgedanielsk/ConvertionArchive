import java.util.Scanner;

class CalculadoraCincoNumeros {
    private double n1, n2, n3, n4, n5;

    public void ingresarNumeros() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese 5 numeros:");
        System.out.print("Numero 1: "); n1 = sc.nextDouble();
        System.out.print("Numero 2: "); n2 = sc.nextDouble();
        System.out.print("Numero 3: "); n3 = sc.nextDouble();
        System.out.print("Numero 4: "); n4 = sc.nextDouble();
        System.out.print("Numero 5: "); n5 = sc.nextDouble();
    }

    public double suma() {
        return n1 + n2 + n3 + n4 + n5;
    }

    public double promedio() {
        return suma() / 5;
    }

    public double maximo() {
        double max = n1;
        if (n2 > max) max = n2;
        if (n3 > max) max = n3;
        if (n4 > max) max = n4;
        if (n5 > max) max = n5;
        return max;
    }

    public double minimo() {
        double min = n1;
        if (n2 < min) min = n2;
        if (n3 < min) min = n3;
        if (n4 < min) min = n4;
        if (n5 < min) min = n5;
        return min;
    }

    public double mediana() {
        double a = n1, b = n2, c = n3, d = n4, e = n5;
        double temp;

        if (a > b) { temp = a; a = b; b = temp; }
        if (a > c) { temp = a; a = c; c = temp; }
        if (a > d) { temp = a; a = d; d = temp; }
        if (a > e) { temp = a; a = e; e = temp; }
        if (b > c) { temp = b; b = c; c = temp; }
        if (b > d) { temp = b; b = d; d = temp; }
        if (b > e) { temp = b; b = e; e = temp; }
        if (c > d) { temp = c; c = d; d = temp; }
        if (c > e) { temp = c; c = e; e = temp; }
        if (d > e) { temp = d; d = e; e = temp; }

        return c;
    }

    public void mostrarResultados() {
        System.out.println("\nSuma: " + suma());
        System.out.println("Promedio: " + promedio());
        System.out.println("Maximo: " + maximo());
        System.out.println("Minimo: " + minimo());
        System.out.println("Mediana: " + mediana());
    }
}

public class P8_CalculadoraCincoNumeros {
    public static void main(String[] args) {
        CalculadoraCincoNumeros calc = new CalculadoraCincoNumeros();
        calc.ingresarNumeros();
        calc.mostrarResultados();
    }
}
