class HolaMundo {
    public void mostrar() {
        System.out.println("Hola Mundo");
    }
}

public class P1_HolaMundo {
    public static void main(String[] args) {
        HolaMundo obj = new HolaMundo();
        obj.mostrar();
    }
}
