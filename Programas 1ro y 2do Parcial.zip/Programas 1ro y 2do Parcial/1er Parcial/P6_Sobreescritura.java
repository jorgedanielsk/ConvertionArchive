import java.util.Scanner;

class CalculadoraSobreescritura {
    protected int a;
    protected int b;

    public void setValores(int x, int y) {
        a = x;
        b = y;
    }

    public int multiplicar() {
        return a * b;
    }

    public int dividir() {
        if (b == 0) {
            System.out.println("No se puede dividir entre cero");
            return 0;
        }
        return a / b;
    }

    public int potencia() {
        int res = 1;
        for (int i = 0; i < b; i++) {
            res *= a;
        }
        return res;
    }
}

class CalculadoraNuevaSobreescritura extends CalculadoraSobreescritura {
    @Override
    public int multiplicar() {
        int res = 0;
        int signo = 1;
        int x = a;
        int y = b;

        if (x < 0) {
            x = -x;
            signo *= -1;
        }

        if (y < 0) {
            y = -y;
            signo *= -1;
        }

        for (int i = 0; i < y; i++) {
            res += x;
        }

        return res * signo;
    }

    @Override
    public int dividir() {
        if (b == 0) {
            System.out.println("No se puede dividir entre cero");
            return 0;
        }

        int signo = 1;
        int x = a;
        int y = b;

        if (x < 0) {
            x = -x;
            signo *= -1;
        }

        if (y < 0) {
            y = -y;
            signo *= -1;
        }

        int cont = 0;
        while (x >= y) {
            x -= y;
            cont++;
        }

        return cont * signo;
    }

    @Override
    public int potencia() {
        if (b < 0) {
            System.out.println("No se soportan exponentes negativos");
            return 0;
        }

        int base = a;
        int exp = b;
        int signo = 1;

        if (base < 0) {
            base = -base;
            if (exp % 2 != 0) {
                signo = -1;
            }
        }

        int res = 1;
        for (int i = 0; i < exp; i++) {
            int temp = 0;
            for (int j = 0; j < base; j++) {
                temp += res;
            }
            res = temp;
        }

        return res * signo;
    }
}

public class P6_Sobreescritura {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CalculadoraNuevaSobreescritura c = new CalculadoraNuevaSobreescritura();
        int x, y;

        System.out.print("Ingresa base y numero: ");
        x = sc.nextInt();
        y = sc.nextInt();

        c.setValores(x, y);

        System.out.println("Multiplicacion (sumas sucesivas): " + c.multiplicar());
        System.out.println("Division (restas sucesivas): " + c.dividir());
        System.out.println("Potencia (multiplicaciones sucesivas): " + c.potencia());
    }
}
