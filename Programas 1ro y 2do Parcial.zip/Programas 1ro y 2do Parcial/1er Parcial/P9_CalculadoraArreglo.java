import java.util.Arrays;
import java.util.Scanner;

class CalculadoraArreglo {
    private double[] numeros = new double[5];

    public void ingresarNumeros() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese 5 numeros:");
        for (int i = 0; i < 5; i++) {
            System.out.print("Numero " + (i + 1) + ": ");
            numeros[i] = sc.nextDouble();
        }
    }

    public double suma() {
        double total = 0;
        for (int i = 0; i < 5; i++) {
            total += numeros[i];
        }
        return total;
    }

    public double promedio() {
        return suma() / 5;
    }

    public double maximo() {
        double max = numeros[0];
        for (int i = 1; i < 5; i++) {
            if (numeros[i] > max) {
                max = numeros[i];
            }
        }
        return max;
    }

    public double minimo() {
        double min = numeros[0];
        for (int i = 1; i < 5; i++) {
            if (numeros[i] < min) {
                min = numeros[i];
            }
        }
        return min;
    }

    public double mediana() {
        double[] temp = numeros.clone();
        Arrays.sort(temp);
        return temp[2];
    }

    public void mostrarResultados() {
        System.out.println("\nSuma: " + suma());
        System.out.println("Promedio: " + promedio());
        System.out.println("Maximo: " + maximo());
        System.out.println("Minimo: " + minimo());
        System.out.println("Mediana: " + mediana());
    }
}

public class P9_CalculadoraArreglo {
    public static void main(String[] args) {
        CalculadoraArreglo calc = new CalculadoraArreglo();
        calc.ingresarNumeros();
        calc.mostrarResultados();
    }
}
