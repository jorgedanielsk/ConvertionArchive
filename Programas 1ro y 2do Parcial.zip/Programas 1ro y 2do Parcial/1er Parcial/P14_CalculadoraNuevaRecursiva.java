import java.util.Scanner;

class CalculadoraBaseRecursiva {
    protected int a;
    protected int b;

    public void setValores(int x, int y) {
        a = x;
        b = y;
    }

    public int multiplicar() {
        return a * b;
    }

    public int dividir() {
        if (b == 0) {
            System.out.println("No se puede dividir entre 0");
            return 0;
        }
        return a / b;
    }

    public int potencia() {
        int res = 1;
        for (int i = 0; i < b; i++) {
            res *= a;
        }
        return res;
    }
}

class CalculadoraNuevaRecursiva extends CalculadoraBaseRecursiva {
    private int multRec(int x, int y) {
        if (y == 0) return 0;
        if (y > 0) return x + multRec(x, y - 1);
        return -multRec(x, -y);
    }

    private int divRec(int x, int y) {
        if (y == 0) return 0;
        boolean negativo = (x < 0) != (y < 0);
        int ax = Math.abs(x);
        int ay = Math.abs(y);
        int res = 0;
        while (ax >= ay) {
            ax -= ay;
            res++;
        }
        return negativo ? -res : res;
    }

    private int potRec(int x, int y) {
        if (y < 0) return 0;
        if (y == 0) return 1;
        return x * potRec(x, y - 1);
    }

    @Override
    public int multiplicar() {
        return multRec(a, b);
    }

    @Override
    public int dividir() {
        if (b == 0) {
            System.out.println("No se puede dividir entre 0");
            return 0;
        }
        return divRec(a, b);
    }

    @Override
    public int potencia() {
        return potRec(a, b);
    }
}

public class P14_CalculadoraNuevaRecursiva {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CalculadoraNuevaRecursiva c = new CalculadoraNuevaRecursiva();

        System.out.print("Ingresa base y numero: ");
        int x = sc.nextInt();
        int y = sc.nextInt();

        c.setValores(x, y);

        System.out.println("Multiplicacion (sumas recursivas): " + c.multiplicar());
        System.out.println("Division (restas recursivas): " + c.dividir());
        System.out.println("Potencia (multiplicaciones recursivas): " + c.potencia());
    }
}
