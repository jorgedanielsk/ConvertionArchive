import java.util.Scanner;

class AutoPE {
    public float precio;
    public int anio;
}

class FuncionesPE {
    public static void mostrarAutoPE(AutoPE autoPE) {
        System.out.println("Auto PE - Precio: $" + autoPE.precio + ", Año: " + autoPE.anio);
    }
}

class AutoPOO {
    public float precio;
    public int anio;

    public AutoPOO(float precio, int anio) {
        this.precio = precio;
        this.anio = anio;
    }

    public void mostrar() {
        System.out.println("Auto POO - Precio: $" + precio + ", Año: " + anio);
    }
}

class PersonaPOO {
    public String nombre;
    public String ap;
    public String am;
    public String genero;
    public int edad;

    public PersonaPOO(String nombre, String ap, String am, String genero, int edad) {
        this.nombre = nombre;
        this.ap = ap;
        this.am = am;
        this.genero = genero;
        this.edad = edad;
    }

    public void mostrar() {
        System.out.println("Persona - Nombre: " + nombre + " " + ap + " " + am);
        System.out.println("Genero: " + genero + ", Edad: " + edad);
    }
}

public class P7_PE_POO {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        AutoPE autoPE = new AutoPE();
        System.out.println("Ingresa datos del Auto (PE):");
        System.out.print("Precio: ");
        autoPE.precio = sc.nextFloat();
        System.out.print("Año: ");
        autoPE.anio = sc.nextInt();

        System.out.println("\n=== Datos desde PE ===");
        FuncionesPE.mostrarAutoPE(autoPE);

        sc.nextLine();

        float precioPOO;
        int anioPOO;
        String nombre, ap, am, genero;
        int edad;

        System.out.println("\nIngresa datos del Auto (POO):");
        System.out.print("Precio: ");
        precioPOO = sc.nextFloat();
        System.out.print("Año: ");
        anioPOO = sc.nextInt();
        sc.nextLine();

        System.out.println("\nIngresa datos de la Persona (POO):");
        System.out.print("Nombre: ");
        nombre = sc.nextLine();
        System.out.print("Apellido paterno: ");
        ap = sc.nextLine();
        System.out.print("Apellido materno: ");
        am = sc.nextLine();
        System.out.print("Genero: ");
        genero = sc.nextLine();
        System.out.print("Edad: ");
        edad = sc.nextInt();

        AutoPOO autoPOO = new AutoPOO(precioPOO, anioPOO);
        PersonaPOO persona = new PersonaPOO(nombre, ap, am, genero, edad);

        System.out.println("\n=== Datos desde POO ===");
        autoPOO.mostrar();
        persona.mostrar();
    }
}
