import java.util.Scanner;

class CalculadoraRecursivaSimple {
    public int sumar(int a, int b) {
        if (b == 0) return a;
        if (b > 0) return sumar(a + 1, b - 1);
        return sumar(a - 1, b + 1);
    }

    public int restar(int a, int b) {
        if (b == 0) return a;
        if (b > 0) return restar(a - 1, b - 1);
        return restar(a + 1, b + 1);
    }

    public int multiplicar(int a, int b) {
        if (b == 0) return 0;
        if (b < 0) return -multiplicar(a, -b);
        return a + multiplicar(a, b - 1);
    }

    public int dividir(int a, int b) {
        if (b == 0) {
            System.out.println("No se puede dividir entre cero");
            return 0;
        }
        if (a < b && a >= 0) return 0;
        if (a < 0 && b > 0) return -dividir(-a, b);
        if (a > 0 && b < 0) return -dividir(a, -b);
        if (a < 0 && b < 0) return dividir(-a, -b);
        return 1 + dividir(a - b, b);
    }

    public double potencia(double a, int b) {
        if (b == 0) return 1;
        if (b < 0) return 1 / potencia(a, -b);
        return a * potencia(a, b - 1);
    }
}

public class P14_CalculadoraRecursiva {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CalculadoraRecursivaSimple calc = new CalculadoraRecursivaSimple();

        System.out.println("=== Calculadora Recursiva ===");
        System.out.print("Introduce el primer numero: ");
        double num1 = sc.nextDouble();
        System.out.print("Introduce el segundo numero: ");
        int num2 = sc.nextInt();

        System.out.println("\n--- Resultados ---");
        System.out.println("Suma: " + calc.sumar((int) num1, num2));
        System.out.println("Resta: " + calc.restar((int) num1, num2));
        System.out.println("Multiplicacion: " + calc.multiplicar((int) num1, num2));
        System.out.println("Division: " + calc.dividir((int) num1, num2));
        System.out.println("Potencia: " + calc.potencia(num1, num2));
    }
}
