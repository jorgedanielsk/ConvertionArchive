import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.util.Random;

class TrianguloPanel extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Random random = new Random();
        int ancho = getWidth();
        int alto = getHeight();

        int x1 = ancho / 2, y1 = 0;
        int x2 = ancho, y2 = alto;
        int x3 = 0, y3 = alto;

        int x = ancho / 2;
        int y = alto / 2;

        for (int i = 0; i < 100000; i++) {
            int d = random.nextInt(3);

            if (d == 0) {
                x = (x + x1) / 2;
                y = (y + y1) / 2;
            } else if (d == 1) {
                x = (x + x2) / 2;
                y = (y + y2) / 2;
            } else {
                x = (x + x3) / 2;
                y = (y + y3) / 2;
            }

            g.drawLine(x, y, x, y);
        }
    }
}

class Triangulo {
    public void trianguloS() {
        JFrame ventana = new JFrame("Triangulo de Sierpinski");
        ventana.setSize(800, 600);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.add(new TrianguloPanel());
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
    }
}

public class P15_TrianguloSierpinski {
    public static void main(String[] args) {
        Triangulo obj = new Triangulo();
        obj.trianguloS();
    }
}
