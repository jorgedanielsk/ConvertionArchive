import java.util.Scanner;

class CalculadoraHerencia {
    protected int a;
    protected int b;

    public void setValores(int x, int y) {
        a = x;
        b = y;
    }

    public int multiplicar() {
        return a * b;
    }

    public int dividir() {
        if (b == 0) {
            System.out.println("No se puede dividir entre cero");
            return 0;
        }
        return a / b;
    }

    public double potencia() {
        int res = 1;
        for (int i = 0; i < b; i++) {
            res *= a;
        }
        return res;
    }
}

class CalculadoraNuevaHerencia extends CalculadoraHerencia {
    @Override
    public int multiplicar() {
        int res = 0;
        int signo = 1;
        int x = a;
        int y = b;

        if (x < 0) {
            x = -x;
            signo *= -1;
        }

        if (y < 0) {
            y = -y;
            signo *= -1;
        }

        for (int i = 0; i < y; i++) {
            res += x;
        }

        return res * signo;
    }

    @Override
    public int dividir() {
        if (b == 0) {
            System.out.println("No se puede dividir entre cero");
            return 0;
        }

        int signo = 1;
        int x = a;
        int y = b;

        if (x < 0) {
            x = -x;
            signo *= -1;
        }

        if (y < 0) {
            y = -y;
            signo *= -1;
        }

        int cont = 0;
        while (x >= y) {
            x -= y;
            cont++;
        }

        return cont * signo;
    }

    @Override
    public double potencia() {
        int base = a;
        int exp = b;
        int signo = 1;

        if (base < 0) {
            base = -base;
            if (exp % 2 != 0) {
                signo = -1;
            }
        }

        int exponente = exp;
        if (exp < 0) {
            exponente = -exp;
        }

        double res = 1.0;
        for (int i = 0; i < exponente; i++) {
            double temp = 0.0;
            for (int j = 0; j < base; j++) {
                temp += res;
            }
            res = temp;
        }

        if (exp < 0) {
            res = 1.0 / res;
        }

        return res * signo;
    }
}

public class P5_Herencia {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x, y;

        System.out.print("Ingresa dos numeros: ");
        x = sc.nextInt();
        y = sc.nextInt();

        CalculadoraNuevaHerencia calc = new CalculadoraNuevaHerencia();
        calc.setValores(x, y);

        System.out.println("\nResultados usando CalculadoraNueva:");
        System.out.println("Multiplicacion: " + calc.multiplicar());
        System.out.println("Division: " + calc.dividir());
        System.out.println("Potencia: " + calc.potencia());
    }
}
