import java.util.Scanner;

class Suma {
    public float operacion(float a, float b) {
        return a + b;
    }
}

public class P2_Suma {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        float a, b, r;
        Suma obj = new Suma();

        System.out.print("Ingresa el parametro 1: ");
        a = sc.nextFloat();
        System.out.print("Ingresa el parametro 2: ");
        b = sc.nextFloat();

        r = obj.operacion(a, b);
        System.out.println("El resultado es: " + r);
    }
}
