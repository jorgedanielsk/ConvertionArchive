import java.util.Scanner;

class Recursividad {
    public int factorial(int num) {
        if (num == 0 || num == 1) {
            return 1;
        }
        return num * factorial(num - 1);
    }

    public int fibonacci(int num) {
        if (num == 0) {
            return 0;
        }
        if (num == 1) {
            return 1;
        }
        return fibonacci(num - 1) + fibonacci(num - 2);
    }
}

public class P14_Recursividad {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Recursividad obj = new Recursividad();

        System.out.print("Ingresa un numero: ");
        int num = sc.nextInt();

        System.out.println("Factorial: " + obj.factorial(num));
        for (int i = 0; i <= num; i++) {
            System.out.print(obj.fibonacci(i) + " ");
        }
        System.out.println();
    }
}
