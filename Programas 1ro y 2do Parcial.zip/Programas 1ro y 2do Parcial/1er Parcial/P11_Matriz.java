import java.util.Scanner;

class Matriz {
    private int[][] m = new int[5][5];

    public void ingresar(Scanner sc) {
        System.out.println("Ingresa los valores de la matriz:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("[" + i + "][" + j + "]: ");
                m[i][j] = sc.nextInt();
            }
        }
    }

    public void mostrar() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(m[i][j] + " ");
            }
            System.out.println();
        }
    }

    public void multiplicacion(int constante) {
        System.out.println("\nResultado de A x " + constante);
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print((m[i][j] * constante) + " ");
            }
            System.out.println();
        }
    }

    public void multiplicacionMatriz(Matriz b) {
        int[][] r = new int[5][5];

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                r[i][j] = 0;
                for (int k = 0; k < 5; k++) {
                    r[i][j] += this.m[i][k] * b.m[k][j];
                }
            }
        }

        System.out.println("\nResultado A * B:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(r[i][j] + " ");
            }
            System.out.println();
        }
    }
}

public class P11_Matriz {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int constante;
        Matriz A = new Matriz();
        Matriz B = new Matriz();

        System.out.println("MATRIZ A");
        A.ingresar(sc);

        System.out.println("\nMATRIZ B");
        B.ingresar(sc);

        System.out.println("\nValores de la matriz A");
        A.mostrar();

        System.out.println("\nValores de la matriz B");
        B.mostrar();

        System.out.print("\nIngresa la constante: ");
        constante = sc.nextInt();

        A.multiplicacion(constante);
        A.multiplicacionMatriz(B);
    }
}
