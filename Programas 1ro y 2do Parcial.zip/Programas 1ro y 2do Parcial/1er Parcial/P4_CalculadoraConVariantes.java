import java.util.Scanner;

class CalculadoraConVariantes {
    private final Scanner sc = new Scanner(System.in);

    public float suma0() {
        System.out.print("Ingresa el primer numero: ");
        float a = sc.nextFloat();
        System.out.print("Ingresa el segundo numero: ");
        float b = sc.nextFloat();
        return a + b;
    }

    public float resta0() {
        System.out.print("Ingresa el primer numero: ");
        float a = sc.nextFloat();
        System.out.print("Ingresa el segundo numero: ");
        float b = sc.nextFloat();
        return a - b;
    }

    public float multiplicacion0() {
        System.out.print("Ingresa el primer numero: ");
        float a = sc.nextFloat();
        System.out.print("Ingresa el segundo numero: ");
        float b = sc.nextFloat();
        return a * b;
    }

    public float division0() {
        System.out.print("Ingresa el primer numero (Dividendo): ");
        float a = sc.nextFloat();
        System.out.print("Ingresa el segundo numero (Divisor): ");
        float b = sc.nextFloat();
        return a / b;
    }

    public float suma2(float a, float b) {
        return a + b;
    }

    public float resta2(float a, float b) {
        return a - b;
    }

    public float multiplicacion2(float a, float b) {
        return a * b;
    }

    public float division2(float a, float b) {
        return a / b;
    }

    public float suma3(float a, float b, float c) {
        return a + b + c;
    }

    public float resta3(float a, float b, float c) {
        return a - b - c;
    }

    public float multiplicacion3(float a, float b, float c) {
        return a * b * c;
    }

    public float division3(float a, float b, float c) {
        return (a / b) / c;
    }
}

public class P4_CalculadoraConVariantes {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CalculadoraConVariantes obj = new CalculadoraConVariantes();
        int opcion1, opcion2;
        float a, b, c;

        System.out.println("--- CALCULADORA ---");
        System.out.println("1. Suma");
        System.out.println("2. Resta");
        System.out.println("3. Multiplicacion");
        System.out.println("4. Division");
        System.out.print("Elige una opcion: ");
        opcion1 = sc.nextInt();

        System.out.println("Elige con cuantos parametros");
        System.out.println("1. 0 Parametros");
        System.out.println("2. 2 Parametros");
        System.out.println("3. 3 Parametros");
        System.out.print("Elige una opcion: ");
        opcion2 = sc.nextInt();

        switch (opcion1) {
            case 1:
                if (opcion2 == 1) {
                    System.out.println("Resultado: " + obj.suma0());
                } else if (opcion2 == 2) {
                    System.out.print("Ingresa el primer numero: ");
                    a = sc.nextFloat();
                    System.out.print("Ingresa el segundo numero: ");
                    b = sc.nextFloat();
                    System.out.println("Resultado: " + obj.suma2(a, b));
                } else if (opcion2 == 3) {
                    System.out.print("Ingresa el primer numero: ");
                    a = sc.nextFloat();
                    System.out.print("Ingresa el segundo numero: ");
                    b = sc.nextFloat();
                    System.out.print("Ingresa el tercer numero: ");
                    c = sc.nextFloat();
                    System.out.println("Resultado: " + obj.suma3(a, b, c));
                }
                break;
            case 2:
                if (opcion2 == 1) {
                    System.out.println("Resultado: " + obj.resta0());
                } else if (opcion2 == 2) {
                    System.out.print("Ingresa el primer numero: ");
                    a = sc.nextFloat();
                    System.out.print("Ingresa el segundo numero: ");
                    b = sc.nextFloat();
                    System.out.println("Resultado: " + obj.resta2(a, b));
                } else if (opcion2 == 3) {
                    System.out.print("Ingresa el primer numero: ");
                    a = sc.nextFloat();
                    System.out.print("Ingresa el segundo numero: ");
                    b = sc.nextFloat();
                    System.out.print("Ingresa el tercer numero: ");
                    c = sc.nextFloat();
                    System.out.println("Resultado: " + obj.resta3(a, b, c));
                }
                break;
            case 3:
                if (opcion2 == 1) {
                    System.out.println("Resultado: " + obj.multiplicacion0());
                } else if (opcion2 == 2) {
                    System.out.print("Ingresa el primer numero: ");
                    a = sc.nextFloat();
                    System.out.print("Ingresa el segundo numero: ");
                    b = sc.nextFloat();
                    System.out.println("Resultado: " + obj.multiplicacion2(a, b));
                } else if (opcion2 == 3) {
                    System.out.print("Ingresa el primer numero: ");
                    a = sc.nextFloat();
                    System.out.print("Ingresa el segundo numero: ");
                    b = sc.nextFloat();
                    System.out.print("Ingresa el tercer numero: ");
                    c = sc.nextFloat();
                    System.out.println("Resultado: " + obj.multiplicacion3(a, b, c));
                }
                break;
            case 4:
                if (opcion2 == 1) {
                    System.out.println("Resultado: " + obj.division0());
                } else if (opcion2 == 2) {
                    System.out.print("Ingresa el primer numero (Dividendo): ");
                    a = sc.nextFloat();
                    System.out.print("Ingresa el segundo numero (Divisor): ");
                    b = sc.nextFloat();
                    System.out.println("Resultado: " + obj.division2(a, b));
                } else if (opcion2 == 3) {
                    System.out.print("Ingresa el primer numero (Dividendo): ");
                    a = sc.nextFloat();
                    System.out.print("Ingresa el segundo numero (Divisor): ");
                    b = sc.nextFloat();
                    System.out.print("Ingresa el tercer numero (Divisor): ");
                    c = sc.nextFloat();
                    System.out.println("Resultado: " + obj.division3(a, b, c));
                }
                break;
            default:
                System.out.println("Opcion no valida");
        }
    }
}
