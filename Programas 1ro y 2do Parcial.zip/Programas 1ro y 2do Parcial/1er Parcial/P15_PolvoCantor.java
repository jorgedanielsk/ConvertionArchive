import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.util.Scanner;

class CantorPanel extends JPanel {
    private final int nivel;

    public CantorPanel(int nivel) {
        this.nivel = nivel;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int ancho = getWidth();
        dibujar(g, 20, 50, ancho - 40, nivel);
    }

    private void dibujar(Graphics g, int x, int y, int longitud, int nivel) {
        if (nivel <= 0 || longitud < 1) {
            return;
        }

        g.drawLine(x, y, x + longitud, y);

        int tercio = longitud / 3;
        dibujar(g, x, y + 40, tercio, nivel - 1);
        dibujar(g, x + 2 * tercio, y + 40, tercio, nivel - 1);
    }
}

class Cantor {
    private int nivel;

    public void ingresar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingresa el nivel del fractal: ");
        nivel = sc.nextInt();

        JFrame ventana = new JFrame("Polvo de Cantor");
        ventana.setSize(800, 600);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.add(new CantorPanel(nivel));
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
    }
}

public class P15_PolvoCantor {
    public static void main(String[] args) {
        Cantor obj = new Cantor();
        obj.ingresar();
    }
}
