import java.util.Scanner;

class PromedioConArreglo {
    private float[] numeros = new float[5];

    public void ingresar() {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            System.out.print("Ingresa numero " + (i + 1) + ": ");
            numeros[i] = sc.nextFloat();
        }
    }

    public void calcular() {
        float promedio;
        float maximo = numeros[0];
        float minimo = numeros[0];
        float suma = 0;

        for (int i = 0; i < 5; i++) {
            suma += numeros[i];

            if (numeros[i] > maximo) {
                maximo = numeros[i];
            }

            if (numeros[i] < minimo) {
                minimo = numeros[i];
            }
        }

        promedio = suma / 5;
        System.out.println("Numero maximo: " + maximo);
        System.out.println("Numero minimo: " + minimo);
        System.out.println("Suma total: " + suma);
        System.out.println("Promedio: " + promedio);
    }
}

public class P10_PromedioConArreglo {
    public static void main(String[] args) {
        PromedioConArreglo obj = new PromedioConArreglo();
        obj.ingresar();
        obj.calcular();
    }
}
