import java.util.Scanner;

class CalculadoraBasica {
    public float suma(float a, float b) {
        return a + b;
    }

    public float resta(float a, float b) {
        return a - b;
    }

    public float multiplicacion(float a, float b) {
        return a * b;
    }

    public float division(float a, float b) {
        return a / b;
    }
}

public class P3_CalculadoraBasica {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CalculadoraBasica obj = new CalculadoraBasica();
        int opcion;
        float a, b;

        System.out.println("--- CALCULADORA ---");
        System.out.println("1. Suma");
        System.out.println("2. Resta");
        System.out.println("3. Multiplicacion");
        System.out.println("4. Division");
        System.out.print("Elige una opcion: ");
        opcion = sc.nextInt();

        switch (opcion) {
            case 1:
                System.out.print("Ingresa el primer numero: ");
                a = sc.nextFloat();
                System.out.print("Ingresa el segundo numero: ");
                b = sc.nextFloat();
                System.out.println("Resultado: " + obj.suma(a, b));
                break;
            case 2:
                System.out.print("Ingresa el primer numero: ");
                a = sc.nextFloat();
                System.out.print("Ingresa el segundo numero: ");
                b = sc.nextFloat();
                System.out.println("Resultado: " + obj.resta(a, b));
                break;
            case 3:
                System.out.print("Ingresa el primer numero: ");
                a = sc.nextFloat();
                System.out.print("Ingresa el segundo numero: ");
                b = sc.nextFloat();
                System.out.println("Resultado: " + obj.multiplicacion(a, b));
                break;
            case 4:
                System.out.print("Ingresa el primer numero (Dividendo): ");
                a = sc.nextFloat();
                System.out.print("Ingresa el segundo numero (Divisor): ");
                b = sc.nextFloat();
                System.out.println("Resultado: " + obj.division(a, b));
                break;
            default:
                System.out.println("Opcion no valida");
        }
    }
}
