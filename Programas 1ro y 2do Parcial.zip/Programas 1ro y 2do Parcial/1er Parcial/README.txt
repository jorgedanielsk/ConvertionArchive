Conversion del primer parcial de C++ a Java.

No incluye menu general ni exportadores XML/HTML/CSV/TXT/JSON.
Cada archivo .java se puede ejecutar de forma independiente.

Para compilar todos:
javac *.java

Para ejecutar un programa:
java P1_HolaMundo
java P2_Suma
java P3_CalculadoraBasica
...

Nota:
Los programas P15 usan ventanas graficas con Swing, porque en Java no existe graphics.h como en C++.
