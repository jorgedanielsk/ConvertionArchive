package Libreria.LibreriaDB;

import java.util.ArrayList;

public abstract class ColaLibreriaDB_Abstracta {
    protected ArrayList<Integer> datos;
    protected int capacidad;

    public ColaLibreriaDB_Abstracta(int capacidad) {
        this.capacidad = capacidad;
        datos = new ArrayList<>();
    }

    public abstract void agregar(int valor);
    public abstract void quitar();
    public abstract void mostrar();
    public abstract boolean estaVacia();
    public abstract boolean estaLlena();
    public abstract int tamanio();
}