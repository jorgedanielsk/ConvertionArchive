package Libreria.LibreriaDB;

public class ColaLibreriaDB_Concreta extends ColaLibreriaDB_Abstracta{
    public ColaLibreriaDB_Concreta(int capacidad) {
        super(capacidad);
    }

    @Override
    public void agregar(int valor) {
        if (estaLlena()) {
            System.out.println("La cola está llena.");
        } else {
            datos.add(valor); // FIFO
        }
    }

    @Override
    public void quitar() {
        if (estaVacia()) {
            System.out.println("La cola está vacía.");
        } else {
            System.out.println("Eliminado: " + datos.remove(0));
        }
    }

    @Override
    public void mostrar() {
        if (estaVacia()) {
            System.out.println("Vacía");
        } else {
            System.out.println(datos);
        }
    }

    @Override
    public boolean estaVacia() {
        return datos.isEmpty();
    }

    @Override
    public boolean estaLlena() {
        return datos.size() == capacidad;
    }

    @Override
    public int tamanio() {
        return datos.size();
    }
}